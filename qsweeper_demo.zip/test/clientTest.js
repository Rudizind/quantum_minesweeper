const assert = chai.assert;
let result = []

describe('result', () => {
    it('should be an array', () => {
        assert.typeOf(result, 'array');
    })
})

// example of what we want:

describe('currentUser', () => {
    it('should have ONLY two properties, called "username" and "password"', () => {
        assert.hasAllKeys(currentUser, ["username", "password"], `currentUser 
            must only have two properties called "username" and "password"`)
    })
    it('should have a string for the username property value', () => {
        assert.typeOf(currentUser.username, "string", "username must be a string");
    })
    it('should have a string for the password property value', () => {
        assert.typeOf(currentUser.password, "string", "password must be a string");
    })
})
